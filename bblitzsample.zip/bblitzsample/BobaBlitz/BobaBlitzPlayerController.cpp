// Copyright Epic Games, Inc. All Rights Reserved.


#include "BobaBlitzPlayerController.h"
#include "EnhancedInputSubsystems.h"
#include "Engine/LocalPlayer.h"
#include "InputMappingContext.h"
#include "BobaBlitzCameraManager.h"

ABobaBlitzPlayerController::ABobaBlitzPlayerController()
{
	// set the player camera manager class
	PlayerCameraManagerClass = ABobaBlitzCameraManager::StaticClass();
}

void ABobaBlitzPlayerController::SetupInputComponent()
{
	Super::SetupInputComponent();

	// Add Input Mapping Context
	if (UEnhancedInputLocalPlayerSubsystem* Subsystem = ULocalPlayer::GetSubsystem<UEnhancedInputLocalPlayerSubsystem>(GetLocalPlayer()))
	{
		for (UInputMappingContext* CurrentContext : DefaultMappingContexts)
		{
			Subsystem->AddMappingContext(CurrentContext, 0);
		}
	}
}
