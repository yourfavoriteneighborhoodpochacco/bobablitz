#include "BobaBlitzWeaponComponent.h"
#include "BobaBlitzProjectile.h"
#include "GameFramework/Actor.h"
#include "Engine/World.h"
#include "Kismet/GameplayStatics.h"
#include "GameFramework/ProjectileMovementComponent.h"
#include "Components/SkeletalMeshComponent.h"
#include "Math/UnrealMathUtility.h"
#include "Particles/ParticleSystemComponent.h"


UBobaBlitzWeaponComponent::UBobaBlitzWeaponComponent()
{
    PrimaryComponentTick.bCanEverTick = true;
    
    // Create muzzle flash component
    MuzzleFlashComponent = CreateDefaultSubobject<UParticleSystemComponent>(TEXT("Muzzle Flash"));
    MuzzleFlashComponent->SetAutoActivate(false);
}

void UBobaBlitzWeaponComponent::BeginPlay()
{
    Super::BeginPlay();

    if (AActor* Owner = GetOwner())
    {
        USkeletalMeshComponent* Mesh = Owner->FindComponentByClass<USkeletalMeshComponent>();
        if (Mesh && MuzzleFlashComponent)
        {
            MuzzleFlashComponent->AttachToComponent(Mesh, FAttachmentTransformRules::SnapToTargetIncludingScale, TEXT("MuzzleSocket"));
        }
    }

}

void UBobaBlitzWeaponComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
    Super::TickComponent(DeltaTime, TickType, ThisTickFunction);

    if (bIsFiring)
    {
        float TimeSinceLastShot = GetWorld()->GetTimeSeconds() - LastFireTime;
        float TimeBetweenShots = 60.0f / FireRate;

        if (TimeSinceLastShot >= TimeBetweenShots)
        {
            FireShot();
            LastFireTime = GetWorld()->GetTimeSeconds();
        }
    }
}



void UBobaBlitzWeaponComponent::StartFiring()
{
    bIsFiring = true;
    RecoilRecoveryTimer = 0.0f;
    LastFireTime = GetWorld()->GetTimeSeconds() - (60.0f / FireRate); // So it fires right away

    FireShot(); // Optionally fire immediately
}


void UBobaBlitzWeaponComponent::StopFiring()
{
    bIsFiring = false;
}

void UBobaBlitzWeaponComponent::FireShot()
{
    if (!ProjectileClass) return;

    UWorld* World = GetWorld();
    if (!World) return;

    // Get spawn location and rotation from owner's mesh or actor
    FVector SpawnLocation;
    FRotator SpawnRotation;

    USkeletalMeshComponent* Mesh = GetOwner()->FindComponentByClass<USkeletalMeshComponent>();
    if (Mesh && Mesh->DoesSocketExist("weapon_r_muzzle"))
    {
        SpawnLocation = Mesh->GetSocketLocation("weapon_r_muzzle");
        SpawnRotation = Mesh->GetSocketRotation("weapon_r_muzzle");
    }
    else
    {
        SpawnLocation = GetOwner()->GetActorLocation();
        SpawnRotation = GetOwner()->GetActorRotation();
    }

    FActorSpawnParameters SpawnParams;
    SpawnParams.Owner = GetOwner();
    SpawnParams.Instigator = Cast<APawn>(GetOwner());

    ABobaBlitzProjectile* Projectile = World->SpawnActor<ABobaBlitzProjectile>(ProjectileClass, SpawnLocation, SpawnRotation, SpawnParams);
    if (Projectile && Projectile->ProjectileMovement)
    {
        Projectile->ProjectileMovement->InitialSpeed = 30000.f; // very fast projectile
        Projectile->ProjectileMovement->MaxSpeed = 30000.f;
    }

    CurrentRecoil += RecoilPerShot;
    CurrentRecoil = FMath::Min(CurrentRecoil, MaxSpread);

    TriggerMuzzleFlash();
}


FVector UBobaBlitzWeaponComponent::CalculateSpreadDirection(const FVector& BaseDirection)
{
    // Calculate total spread (base + recoil)
    float TotalSpread = BaseSpread + CurrentRecoil;
    TotalSpread = FMath::Min(TotalSpread, MaxSpread);
    
    // Generate random spread angles
    float SpreadYaw = FMath::RandRange(-TotalSpread, TotalSpread);
    float SpreadPitch = FMath::RandRange(-TotalSpread, TotalSpread);

    // Create rotation from spread angles
    FRotator SpreadRotation = FRotator(SpreadPitch, SpreadYaw, 0.0f);

    // Apply spread to base direction
    FVector SpreadDirection = BaseDirection.RotateAngleAxis(SpreadYaw, FVector::UpVector);
    SpreadDirection = SpreadDirection.RotateAngleAxis(SpreadPitch, FVector::RightVector);

    return SpreadDirection.GetSafeNormal();
}

void UBobaBlitzWeaponComponent::TriggerMuzzleFlash()
{
    if (MuzzleFlashComponent)
    {
        MuzzleFlashComponent->ActivateSystem(true);
    }
}
