#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "BobaBlitzWeaponComponent.generated.h"


UCLASS(ClassGroup=(Custom), meta=(BlueprintSpawnableComponent))
class BOBABLITZ_API UBobaBlitzWeaponComponent : public UActorComponent
{
    GENERATED_BODY()

    public:
        UBobaBlitzWeaponComponent();

    protected:
    virtual void BeginPlay() override;

    private:
    void FireShot();

    public:
    virtual void TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;

    //Weapon properties
    

    UPROPERTY(EditDefaultsOnly, Category = "Weapon")
    float BaseSpread = 3.0f;

    UPROPERTY(EditDefaultsOnly, Category = "Weapon")
    float MaxSpread = 12.0f;

    UPROPERTY(EditDefaultsOnly, Category = "Weapon")
    float RecoilPerShot = 0.8f;

    UPROPERTY(EditDefaultsOnly, Category = "Weapon")
    float RecoilRecoveryRate = 2.0f;

    UPROPERTY(EditDefaultsOnly, Category = "Weapon")
    float FireRate = 1200.0f;

    UPROPERTY(EditDefaultsOnly, Category = "Weapon")
    TSubclassOf<class ABobaBlitzProjectile> ProjectileClass;

    //Current state
    UPROPERTY(EditDefaultsOnly, Category = "Weapon")
    float CurrentRecoil = 0.0f;

    UPROPERTY(EditDefaultsOnly, Category = "Weapon")
    bool bIsFiring = false;

    //Functions
    UFUNCTION(BlueprintCallable, Category = "Weapon")
    void StartFiring();

    UFUNCTION(BlueprintCallable, Category = "Weapon")
    void StopFiring();

    UFUNCTION(BlueprintCallable, Category = "Weapon")
    FVector CalculateSpreadDirection(const FVector& BaseDirection);

    // Visual effects
    UFUNCTION(BlueprintCallable, Category = "Weapon")
    void TriggerMuzzleFlash();

    // Muzzle flash component
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Weapon")
    class UParticleSystemComponent* MuzzleFlashComponent;

private:
    float LastFireTime = 0.0f;
    float RecoilRecoveryTimer = 0.0f;
};