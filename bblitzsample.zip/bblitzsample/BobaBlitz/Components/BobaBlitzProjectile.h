#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "BobaBlitzProjectile.generated.h"

UCLASS()
class BOBABLITZ_API ABobaBlitzProjectile : public AActor
{
    GENERATED_BODY()
    
public:	
    ABobaBlitzProjectile();

protected:
    virtual void BeginPlay() override;

public:	
    UPROPERTY(VisibleDefaultsOnly, Category = "Components")
    UStaticMeshComponent* ProjectileMesh;

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Movement")
    class UProjectileMovementComponent* ProjectileMovement;

    UPROPERTY(EditDefaultsOnly, Category = "Damage")
    float Damage = 25.0f;

    UFUNCTION()
    void OnHit(UPrimitiveComponent* HitComp, AActor* OtherActor, 
               UPrimitiveComponent* OtherComp, FVector NormalImpulse, 
               const FHitResult& Hit);
};
