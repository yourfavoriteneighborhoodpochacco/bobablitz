#include "BobaBlitzProjectile.h"
#include "GameFramework/ProjectileMovementComponent.h"
#include "Components/StaticMeshComponent.h"
#include "Kismet/GameplayStatics.h"
#include "UObject/ConstructorHelpers.h"

ABobaBlitzProjectile::ABobaBlitzProjectile()
{
    PrimaryActorTick.bCanEverTick = false;

    ProjectileMesh = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("BobaMesh"));
    static ConstructorHelpers::FObjectFinder<UStaticMesh> BobaMeshObj(TEXT("/Game/Meshes/SM_BobaBall"));
    if (BobaMeshObj.Succeeded())
    {
        ProjectileMesh->SetStaticMesh(BobaMeshObj.Object);
    }
    else
    {
        UE_LOG(LogTemp, Warning, TEXT("Boba projectile mesh not found! Check path."));
    }

    ProjectileMesh->SetCollisionProfileName(TEXT("BlockAllDynamic"));
    ProjectileMesh->OnComponentHit.AddDynamic(this, &ABobaBlitzProjectile::OnHit);
    RootComponent = ProjectileMesh;

    ProjectileMovement = CreateDefaultSubobject<UProjectileMovementComponent>(TEXT("ProjectileMovement"));
    ProjectileMovement->bRotationFollowsVelocity = true;
    ProjectileMovement->bShouldBounce = false;
    ProjectileMovement->ProjectileGravityScale = 0.0f;
    ProjectileMovement->InitialSpeed = 20000.0f; // super fast
    ProjectileMovement->MaxSpeed = 20000.0f;

    Damage = 10.0f; // default damage value
}

void ABobaBlitzProjectile::BeginPlay()
{
    Super::BeginPlay();
}

void ABobaBlitzProjectile::OnHit(UPrimitiveComponent* HitComp, AActor* OtherActor,
                                 UPrimitiveComponent* OtherComp, FVector NormalImpulse,
                                 const FHitResult& Hit)
{
    if (OtherActor && OtherActor != this && OtherComp)
    {
        UGameplayStatics::ApplyPointDamage(OtherActor, Damage, GetActorForwardVector(),
                                           Hit, nullptr, this, nullptr);

        Destroy();
    }
}
