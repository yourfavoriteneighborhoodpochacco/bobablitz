#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "Blueprint/UserWidget.h"
#include "BobaBlitzUIManager.generated.h"

UCLASS()
class BOBABLITZ_API ABobaBlitzUIManager : public AActor
{
    GENERATED_BODY()

    public:
    ABobaBlitzUIManager();

    protected:
    virtual void BeginPlay() override;

    public:
    //UI Widget Classes
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "UI")
    TSubclassOf<UUserWidget> StartScreenClass;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "UI")
    TSubclassOf<UUserWidget> ProfileScreenClass;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "UI")
    TSubclassOf<UUserWidget> HomeScreenClass;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "UI")
    TSubclassOf<UUserWidget> HangarScreenClass;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "UI")
    TSubclassOf<UUserWidget> QueueingScreenClass;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "UI")
    TSubclassOf<UUserWidget> SettingsScreenClass;

    //Current active widget
    UPROPERTY(EditAnywhere, Category = "UI")
    UUserWidget* CurrentWidget;

    //Functions to switch between widgets
    UFUNCTION(BlueprintCallable, Category = "UI")
    void SwitchToStartScreen();

    UFUNCTION(BlueprintCallable, Category = "UI")
    void SwitchToProfileScreen();

    UFUNCTION(BlueprintCallable, Category = "UI")
    void SwitchToHomeScreen();

    UFUNCTION(BlueprintCallable, Category = "UI")
    void SwitchToHangarScreen();

    UFUNCTION(BlueprintCallable, Category = "UI")
    void SwitchToQueueingScreen();

    UFUNCTION(BlueprintCallable, Category = "UI")
    void SwitchToSettingsScreen();
};