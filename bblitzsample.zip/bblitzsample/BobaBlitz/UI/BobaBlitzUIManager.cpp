#include "BobaBlitzUIManager.h"
#include "Blueprint/UserWidget.h"

ABobaBlitzUIManager::ABobaBlitzUIManager()
{
    PrimaryActorTick.bCanEverTick = true;
}

void ABobaBlitzUIManager::BeginPlay()
{
    Super::BeginPlay();

    SwitchToStartScreen();
}

void ABobaBlitzUIManager::SwitchToStartScreen()
{

    if(CurrentWidget)
    {
        CurrentWidget->RemoveFromParent();
        CurrentWidget = nullptr;
    }

    if(StartScreenClass)
    {
        CurrentWidget = CreateWidget<UUserWidget>(GetWorld(), StartScreenClass);
        if(CurrentWidget)
        {
            CurrentWidget->AddToViewport();
        }
    }
}

void ABobaBlitzUIManager::SwitchToProfileScreen()
{
    if(CurrentWidget)
    {
        CurrentWidget->RemoveFromParent();
        CurrentWidget = nullptr;
    }

    if(ProfileScreenClass)
    {
        CurrentWidget = CreateWidget<UUserWidget>(GetWorld(), ProfileScreenClass);
        if(CurrentWidget)
        {
            CurrentWidget->AddToViewport();
        }
    }
}

void ABobaBlitzUIManager::SwitchToHomeScreen()
{
    if(CurrentWidget)
    {
        CurrentWidget->RemoveFromParent();
        CurrentWidget = nullptr;
    }

    if(HomeScreenClass)
    {
        CurrentWidget = CreateWidget<UUserWidget>(GetWorld(), HomeScreenClass);
        if(CurrentWidget)
        {
            CurrentWidget->AddToViewport();
        }
    }
}

void ABobaBlitzUIManager::SwitchToHangarScreen()
{
    if(CurrentWidget)
    {
        CurrentWidget->RemoveFromParent();
        CurrentWidget = nullptr;
    }

    if(HangarScreenClass)
    {
        CurrentWidget = CreateWidget<UUserWidget>(GetWorld(), HangarScreenClass);
        if(CurrentWidget)
        {
            CurrentWidget->AddToViewport();
        }
    }
}

void ABobaBlitzUIManager::SwitchToQueueingScreen()
{
    if(CurrentWidget)
    {
        CurrentWidget->RemoveFromParent();
        CurrentWidget = nullptr;
    }

    if(QueueingScreenClass)
    {
        CurrentWidget = CreateWidget<UUserWidget>(GetWorld(), QueueingScreenClass);
        if(CurrentWidget)
        {
            CurrentWidget->AddToViewport();
        }
    }
}

void ABobaBlitzUIManager::SwitchToSettingsScreen()
{
    if(CurrentWidget)
    {
        CurrentWidget->RemoveFromParent();
        CurrentWidget = nullptr;
    }

    if(SettingsScreenClass)
    {
        CurrentWidget = CreateWidget<UUserWidget>(GetWorld(), SettingsScreenClass);
        if(CurrentWidget)
        {
            CurrentWidget->AddToViewport();
        }
    }
}