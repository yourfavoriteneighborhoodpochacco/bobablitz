// Copyright Epic Games, Inc. All Rights Reserved.


#include "Variant_Shooter/ShooterWeaponHolder.h"

// Add default functionality here for any IShooterWeaponHolder functions that are not pure virtual.
